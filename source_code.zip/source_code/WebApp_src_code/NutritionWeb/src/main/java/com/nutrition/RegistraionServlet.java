package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

public class RegistraionServlet extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response){

		PrintWriter pw=null;
		try{

			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String id = getRandom();

			pw =  response.getWriter();
			String sqlQuery = "INSERT INTO TLB_USER (USER_ID, NAME, PHONE, EMAIL, PASSWORD) values(?,?,?,?,?)";
			Connection conn = DBConnection.createDbConnection();
			PreparedStatement stmt = conn.prepareStatement(sqlQuery);
			stmt.setString(1,id);
			stmt.setString(2,name);
			stmt.setString(3,phone);
			stmt.setString(4,email);
			stmt.setString(5,password);

			int result =  stmt.executeUpdate();

			stmt.close();
			conn.close();

			if(result>0){
				pw.write(id);
			}else{
				pw.write("Failed");
			}
		}catch(Exception ex){
			pw.write(ex.getMessage());
		}
	}

	public String getRandom(){
		Random random = new Random();
		int number = 1 + random.nextInt(1000000);
		return  String.valueOf(number);
	}

}
