package com.nutrition;

import javax.servlet.http.*;

import java.io.PrintWriter;
import java.sql.*;

public class FoodItemServlet extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response){
		PrintWriter pw=null;
		try{
			
			pw =  response.getWriter();
			
			String sqlQuery = "SELECT FOOD_ID, FOOD_NAME, CATEGORY, SERVING_SIZE FROM TLB_MEAL_ITEM  ORDER BY CATEGORY, FOOD_NAME";
			Connection conn = DBConnection.createDbConnection();
			PreparedStatement stmt = conn.prepareStatement(sqlQuery);
			ResultSet rs =  stmt.executeQuery();
			String result=null;
			while(rs.next()){
				String id =  rs.getString("FOOD_ID");
				String name =  rs.getString("FOOD_NAME");
				String category =  rs.getString("CATEGORY");
				String servingSize =  rs.getString("SERVING_SIZE");
				
				String line = id+"#"+name+"#"+category+"#"+servingSize;

				if(result!=null){
					result = result+"\n" +line;
				}else{
					result = line;
				}

			}
			rs.close();
			stmt.close();
			conn.close();

			pw.write(result);
			
		}catch(Exception ex){
			pw.write(ex.getMessage());
		}
	}

}
