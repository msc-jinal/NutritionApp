package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MedicalProfileServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw = null;
        try{
            pw = response.getWriter();
            String id = request.getParameter("id");
            String sqlQuery = "SELECT * FROM tlb_medical_profile WHERE USER_ID=?";
            Connection connection = DBConnection.createDbConnection();
            PreparedStatement stmt = connection.prepareStatement(sqlQuery);
            stmt.setString(1,id);
            ResultSet result = stmt.executeQuery();

            String userData="";
            if(result.next()){
                userData= "AGE="+result.getString("AGE")+",";
                userData += "GENDER="+result.getString("GENDER")+",";
                userData += "WEIGHT="+result.getString("WEIGHT")+",";
                userData += "HEIGHT="+result.getString("HEIGHT")+",";
                userData += "LIFESTYLE="+result.getString("LIFESTYLE")+",";
                userData += "SUGAR="+result.getString("SUGAR")+",";
                userData += "BP="+result.getString("BP")+",";
                userData += "HAEMOGLOBIN="+result.getString("HAEMOGLOBIN")+",";
                userData += "POTASSIUM="+result.getString("POTASSIUM")+",";
                userData += "SODIUM="+result.getString("SODIUM")+",";
                userData += "CALCIUM="+result.getString("CALCIUM")+",";
                userData += "CHOLESTEROL="+result.getString("CHOLESTEROL")+",";
                userData += "TRIGLYCERIDE="+result.getString("TRIGLYCERIDE")+",";
                userData += "HDL="+result.getString("HDL")+",";
                userData += "LDL="+result.getString("LDL")+",";
                userData += "VLDL="+result.getString("VLDL");
            }

            pw.write(userData);

        }catch(Exception e){
            pw.write("Error!!!"+e.getMessage());
        }

    }
}
