package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CreateMedicalProfileServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw=null;
        try{
            pw = response.getWriter();//define printwriter class object

            String id = request.getParameter("id");
            String age = request.getParameter("age");
            String gender = request.getParameter("gender");
            String weight = request.getParameter("weight");
            String height = request.getParameter("height");
            String lifestyle = request.getParameter("lifestyle");
            String sugar = request.getParameter("sugar");
            String bp = request.getParameter("bp");
            String haemoglobin = request.getParameter("haemoglobin");
            String potassium = request.getParameter("potassium");
            String sodium= request.getParameter("sodium");
            String calcium = request.getParameter("calcium");
            String cholesterol = request.getParameter("cholesterol");
            String triglyceride = request.getParameter("triglyceride");
            String hdl = request.getParameter("hdl");
            String ldl = request.getParameter("ldl");
            String vldl = request.getParameter("vldl");

            SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");
            String date = sdf.format(new Date());

            deleteProfile(id);

            String sqlQuery="INSERT INTO TLB_MEDICAL_PROFILE (USER_ID, AGE, GENDER, WEIGHT, HEIGHT, LIFESTYLE, SUGAR, BP, HAEMOGLOBIN, POTASSIUM, SODIUM, CALCIUM, CHOLESTEROL, TRIGLYCERIDE, HDL, LDL, VLDL, LAST_UPDATED)" +
                    " Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            Connection connect = DBConnection.createDbConnection();
            PreparedStatement stmt = connect.prepareStatement(sqlQuery);
            stmt.setString(1,id);
            stmt.setString(2,age);
            stmt.setString(3,gender);
            stmt.setString(4,weight);
            stmt.setString(5,height);
            stmt.setString(6,lifestyle);
            stmt.setString(7,sugar);
            stmt.setString(8,bp);
            stmt.setString(9,haemoglobin);
            stmt.setString(10,potassium);
            stmt.setString(11,sodium);
            stmt.setString(12,calcium);
            stmt.setString(13,cholesterol);
            stmt.setString(14,triglyceride);
            stmt.setString(15,hdl);
            stmt.setString(16,ldl);
            stmt.setString(17,vldl);
            stmt.setString(18,date);

            int result=stmt.executeUpdate();
            if(result>0){
                pw.write("Success");
            }else{
                pw.write("Failed");
            }

            stmt.close();
            connect.close();
        }catch(Exception e){
            pw.write("Failed");
            pw.write(e.getMessage());
        }

    }

    public void deleteProfile(String userId){
        try{
            String sqlQuery = "Delete From tlb_medical_profile where user_id=?";
            Connection connect = DBConnection.createDbConnection();
            PreparedStatement stmt = connect.prepareStatement(sqlQuery);
            stmt.setString(1,userId);
            stmt.executeUpdate();

            stmt.close();
            connect.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
