package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginServlet extends HttpServlet{

    protected void doPost(HttpServletRequest requset, HttpServletResponse response){
        PrintWriter pw=null;
        try{
            pw = response.getWriter();

            String email = requset.getParameter("email");
            String password = requset.getParameter("password");

            String query = "SELECT * FROM TLB_USER WHERE email=? and password=?";
            Connection connect = DBConnection.createDbConnection();//create database connection
            PreparedStatement statement = connect.prepareStatement(query);//prepare statement
            statement.setString(1,email);
            statement.setString(2,password);

            ResultSet loginResult = statement.executeQuery();
            String result;
            if(loginResult.next()){
                result = loginResult.getString("USER_ID");
            }else{
                result ="Failed";
            }

            loginResult.close();
            statement.close();
            connect.close();

            pw.write(result);

        }catch(Exception e){
            pw.write("Failed");
            pw.write(e.getMessage());
        }

    }
}

