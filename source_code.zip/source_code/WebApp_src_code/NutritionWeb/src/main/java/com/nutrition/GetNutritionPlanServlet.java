package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class GetNutritionPlanServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw=null;
        try{
            pw = response.getWriter();

            String id = request.getParameter("id");
            String sqlQuery = "SELECT * FROM TLB_NUTRITION_PLAN WHERE USER_ID=?";
            Connection connection = DBConnection.createDbConnection();
            PreparedStatement stmt = connection.prepareStatement(sqlQuery);
            stmt.setString(1,id);

            ResultSet result = stmt.executeQuery();
            String nutritionData="";
            if(result.next()){
                nutritionData= "CALORIES="+result.getString("CALORIES")+",";
                nutritionData += "PROTEIN="+result.getString("PROTEIN")+",";
                nutritionData += "CARBOHYDRATE="+result.getString("CARBOHYDRATE")+",";
                nutritionData += "SUGAR="+result.getString("SUGAR")+",";
                nutritionData += "FIBER="+result.getString("FIBER")+",";
                nutritionData += "IRON="+result.getString("IRON")+",";
                nutritionData += "CALCIUM="+result.getString("CALCIUM")+",";
                nutritionData += "SODIUM="+result.getString("SODIUM")+",";
                nutritionData += "POTASSIUM="+result.getString("POTASSIUM");
            }
            result.close();
            stmt.close();
            connection.close();
            pw.write(nutritionData);

        }catch(Exception e){
            pw.write("Error!!!!");
            pw.write(e.getMessage());
        }

    }
}
