package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

public class FoodHistoryServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw = null;
        try{
            pw = response.getWriter();
            String id = request.getParameter("id");
            String date = request.getParameter("date");
            //Step 1:  get food data like foodid and serving size from tlb_daily_meal table
            String sqlQuery = "SELECT * FROM tlb_daily_meal,tlb_meal_item WHERE tlb_daily_meal.FOOD_ID = tlb_meal_item.FOOD_ID " +
                    "AND tlb_daily_meal.USER_ID=? AND tlb_daily_meal.DATE=?";
            Connection connect = DBConnection.createDbConnection();
            PreparedStatement stmt = connect.prepareStatement(sqlQuery);
            stmt.setString(1,id);
            stmt.setString(2,date);

            ResultSet result = stmt.executeQuery();
            String nutritionData="";

            while(result.next()){

                String quantity = result.getString("SERVING_QNT");
                String foodName = result.getString("FOOD_NAME");
                String servingSize = result.getString("SERVING_SIZE");
                nutritionData = nutritionData +"FoodName="+foodName+"#"+"ServingSize="+servingSize+"#"+"ServingQnt="+quantity+"@";

            }
            result.close();
            stmt.close();
            connect.close();
            pw.write(nutritionData);

        }catch (Exception ex){
            pw.write("Error!"+ex.getMessage());
        }
    }
}
