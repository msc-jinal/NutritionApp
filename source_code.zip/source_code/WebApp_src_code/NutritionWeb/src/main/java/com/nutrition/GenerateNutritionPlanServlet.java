package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.HashMap;

public class GenerateNutritionPlanServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw=null;
        try{
            //step1: a using age and gender find nutrition records from nutritionmasterplan table
            pw = response.getWriter();
            String userid = request.getParameter("id");
            int age = Integer.parseInt( request.getParameter("age"));
            String gender = request.getParameter("gender");
            gender = gender.toUpperCase();
            String weight = request.getParameter("weight");
            String height = request.getParameter("height");
            String lifestyle = request.getParameter("lifestyle");

            String sqlQuery = "SELECT * FROM TLB_NUTRITION_PLAN_MASTER WHERE ? >= Min_age and ? <= max_age and gender = ?";
            Connection connection = DBConnection.createDbConnection();
            PreparedStatement stmt = connection.prepareStatement(sqlQuery);
            stmt.setInt(1,age);
            stmt.setInt(2,age);
            stmt.setString(3,gender);

            ResultSet result = stmt.executeQuery();

            HashMap<String,String> map = new HashMap();
            String protein = getProtein(weight);
            String calories = getCalories(gender,age,weight,height,lifestyle);
            String carbohydrate = getCarbs(calories);
            String fat = getFat(calories);
            ////step2: write all these records into nutrition plan using user id.
            if(result.next()){

                map.put("CALORIES",calories);
                map.put("PROTEIN",protein);
                map.put("FAT",fat);
                map.put("CARBOHYDRATE",carbohydrate);
                map.put("SUGAR",result.getString("SUGAR"));
                map.put("FIBER",result.getString("FIBER"));
                map.put("IRON",result.getString("IRON"));
                map.put("CALCIUM",result.getString("CALCIUM"));
                map.put("SODIUM",result.getString("SODIUM"));
                map.put("POTASSIUM",result.getString("POTASSIUM"));
            }
            result.close();
            stmt.close();
            connection.close();
            boolean isInserted = insertUserNutritionPlan(userid,map);
            if(isInserted){
                pw.write("Success!!");
            }else{
                pw.write("Fail!!");
            }

        }catch(Exception e){
            pw.write("Error!!");
            pw.write(e.getMessage());
        }
    }
    private boolean insertUserNutritionPlan(String id, HashMap<String, String> map){

        try{
            deleteNutritionPlan(id);

            String sqlQuery1 = "INSERT INTO TLB_NUTRITION_PLAN (USER_ID, CALORIES, PROTEIN, TOTAL_FAT, CARBOHYDRATE, SUGAR, FIBER, IRON, CALCIUM, SODIUM, POTASSIUM, LAST_UPDATED)" +
                    " values(?,?,?,?,?,?,?,?,?,?,?,?)";
            Date today = new Date();

            Connection connect = DBConnection.createDbConnection();
            PreparedStatement stmt = connect.prepareStatement(sqlQuery1);
            stmt.setString(1,id);
            stmt.setString(2,map.get("CALORIES"));
            stmt.setString(3,map.get("PROTEIN"));
            stmt.setString(4,map.get("FAT"));
            stmt.setString(5,map.get("CARBOHYDRATE"));
            stmt.setString(6,map.get("SUGAR"));
            stmt.setString(7,map.get("FIBER"));
            stmt.setString(8,map.get("IRON"));
            stmt.setString(9,map.get("CALCIUM"));
            stmt.setString(10,map.get("SODIUM"));
            stmt.setString(11,map.get("POTASSIUM"));
            stmt.setString(12,today.toString());

            stmt.executeUpdate();

            stmt.close();
            connect.close();

            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public void deleteNutritionPlan(String userId){
        try{
            String sqlQuery = "Delete From TLB_NUTRITION_PLAN where user_id=?";
            Connection connect = DBConnection.createDbConnection();
            PreparedStatement stmt = connect.prepareStatement(sqlQuery);
            stmt.setString(1,userId);
            stmt.executeUpdate();

            stmt.close();
            connect.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public String getProtein(String weight){
        float w =  Float.parseFloat(weight);
        double pro = (w*0.8);
        String protein = Double.toString(Math.round(pro));

        return protein;
    }

    public String getCalories(String gender,int age,String weight,String height,String lifestyle){
        double pal=0;
        if(lifestyle.equalsIgnoreCase("Sedentary")){
            pal=1.0;
        }
        else if(lifestyle.equalsIgnoreCase("Active")){
            pal=1.27;
        }
        else if(lifestyle.equalsIgnoreCase("Hardworking")){
            pal=1.45;
        }
        float w =  Float.parseFloat(weight);
        float h = (Float.parseFloat(height))/100;
        double cal=0;
        if(gender.equalsIgnoreCase("male")){
            cal = 354.1 - (6.91*age) + (pal * ((15.91 * w) + (539.6 * h)));
        }
        else{
            cal = 354.1 - (6.91*age) + (pal * ((9.36 * w) + (726 * h)));

        }
        String calory = Double.toString(Math.round(cal));
        return calory;
    }

    public String getCarbs(String calories){
        float cal = Float.parseFloat(calories);
        int carb = Math.round((cal*55)/400);
        String carbs = Integer.toString(carb);

        return carbs;
    }

    public String getFat(String calories){
        float cal = Float.parseFloat(calories);
        int f = Math.round((cal*27)/900);
        String fat = Integer.toString(f);

        return fat;
    }


}
