package com.nutrition;


import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;


public class CalculateNutritionValueServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw=null;
        try{
            pw = response.getWriter();
           //step1 : collect daily meal record for given userid and date
            String id = request.getParameter("id");
            String date = request.getParameter("date");

            String sqlQuery = "SELECT * FROM tlb_daily_meal,tlb_meal_item WHERE tlb_daily_meal.FOOD_ID = tlb_meal_item.FOOD_ID " +
                    "AND tlb_daily_meal.USER_ID=? AND tlb_daily_meal.DATE=? order by tlb_meal_item.food_name";
            Connection connect = DBConnection.createDbConnection();
            PreparedStatement stmt = connect.prepareStatement(sqlQuery);
            stmt.setString(1,id);
            stmt.setString(2,date);

            ResultSet rs = stmt.executeQuery();
            String result="";
            ArrayList<HashMap> myNutritionlist =  new ArrayList<HashMap>();

            while(rs.next()){
                String servingqnt = rs.getString("serving_qnt");

                HashMap<String,Float> map = new HashMap();
                map.put("CALORIES", countNutrition(rs.getString("CALORIES"),servingqnt));
                map.put("PROTEIN",countNutrition(rs.getString("PROTEIN"),servingqnt));
                map.put("CARBOHYDRATE",countNutrition(rs.getString("CARBOHYDRATE"),servingqnt));
                map.put("SUGAR",countNutrition(rs.getString("SUGAR"),servingqnt));
                map.put("FIBER",countNutrition(rs.getString("FIBER"),servingqnt));
                map.put("IRON",countNutrition(rs.getString("IRON"),servingqnt));
                map.put("CALCIUM",countNutrition(rs.getString("CALCIUM"),servingqnt));
                map.put("SODIUM",countNutrition(rs.getString("SODIUM"),servingqnt));
                map.put("POTASSIUM",countNutrition(rs.getString("POTASSIUM"),servingqnt));
                myNutritionlist.add(map);

            }
            rs.close();
            stmt.close();
            connect.close();

            //step3: calculate nutrition values for all foods
            float tCalories=0;
            float tProtein =0;
            float tCarbohydrate=0;
            float tSugar =0;
            float tFiber = 0;
            float tIron = 0;
            float tCacium = 0;
            float tSodium = 0;
            float tPotassium = 0;

            for(int i= 0;i<myNutritionlist.size();i++){
               HashMap<String,Float> hm1 =  myNutritionlist.get(i);
               tCalories =  tCalories + hm1.get("CALORIES");
               tProtein = tProtein+ hm1.get("PROTEIN");
               tCarbohydrate = tCarbohydrate + hm1.get("CARBOHYDRATE");
               tSugar = tSugar + hm1.get("SUGAR");
               tFiber = tFiber + hm1.get("FIBER");
               tIron = tIron + hm1.get("IRON");
               tCacium = tCacium + hm1.get("CALCIUM");
               tSodium = tSodium + hm1.get("SODIUM");
               tPotassium = tPotassium + hm1.get("POTASSIUM");

            }
            String nutritionData= "CALORIES="+Math.round(tCalories)+",";
            nutritionData += "PROTEIN="+Math.round(tProtein)+",";
            nutritionData += "CARBOHYDRATE="+Math.round(tCarbohydrate)+",";
            nutritionData += "SUGAR="+Math.round(tSugar)+",";
            nutritionData += "FIBER="+Math.round(tFiber)+",";
            nutritionData += "IRON="+Math.round(tIron)+",";
            nutritionData += "CALCIUM="+Math.round(tCacium)+",";
            nutritionData += "SODIUM="+Math.round(tSodium)+",";
            nutritionData += "POTASSIUM="+Math.round(tPotassium);

            pw.write(nutritionData);

        }catch(Exception e){
            pw.write("Error!!!!");
            pw.write(e.getMessage());
        }
    }

    private float countNutrition(String nutriValue,String servingQnt){
        try {
            float value = Float.parseFloat(nutriValue);
            int served = Integer.parseInt(servingQnt);
            float totalValue = value * served;
            return totalValue;
        }catch (Exception ex){
            return 0;
        }
    }
}
