package com.nutrition;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DailyMealServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response){
        PrintWriter pw=null;
        try{
            pw=response.getWriter();
            String id=request.getParameter("id");
            String foodid = request.getParameter("foodid");
            String servingsize = request.getParameter("servingsize");
            String date = request.getParameter("date");

            String sqlQuery = "INSERT INTO TLB_DAILY_MEAL (USER_ID, FOOD_ID, SERVING_QNT, DATE)" + " Values(?,?,?,?)";

            Connection connection = DBConnection.createDbConnection();
            PreparedStatement stmt = connection.prepareStatement(sqlQuery);
            stmt.setString(1,id);
            stmt.setString(2,foodid);
            stmt.setString(3,servingsize);
            stmt.setString(4,date);

            int result=stmt.executeUpdate();

            stmt.close();
            connection.close();

            if(result>0){
                pw.write("Success");
            }else{
                pw.write("Failed");
            }

        }catch (Exception e){
            pw.write("Failed");
            pw.write(e.getMessage());
        }

    }

}
