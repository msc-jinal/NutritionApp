package com.nutrition;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class PrepareMealRecordActivity extends AppCompatActivity {
    ArrayList<String> myMealList;
    String userId;
    ArrayList<String> foodIds;
    ArrayList<TextView> foodItems;
    ArrayList<ElegantNumberButton> elegantBtns;
    EditText editTextDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prepare_meal_record);
        setTitle("Prepare Meal");

        //inputDate
        editTextDate = (EditText) findViewById(R.id.textView_date);

        Date today = new Date();
        editTextDate.setText(dataToString(today));
        editTextDate.setOnClickListener(new EditDateListner());

        Intent intent = getIntent();
        userId=intent.getStringExtra(Configs.USERID_PARAM_NAME);
        myMealList = (ArrayList) intent.getSerializableExtra("mySelectedList");
        LinearLayout linearLayout = (LinearLayout)findViewById(R.id.id_linearLayout);

        foodIds = new ArrayList<>();
        foodItems = new ArrayList<>();
        elegantBtns = new ArrayList<>();

        for(int i=0;i<myMealList.size();i++){

            LinearLayout rowLayout = new LinearLayout(this);
            rowLayout.setPadding(0,15,0,5);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);

            LinearLayout textLayout = new LinearLayout(this);
            textLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams rowLayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT,1.0f);
            textLayout.setLayoutParams(rowLayoutParam);

            String str = myMealList.get(i);
            String[] temp = str.split("#");

            TextView textViewFoodItem = new TextView(this);
            textViewFoodItem.setText(temp[1]);

            TextView textViewServingSize = new TextView(this);
            textViewServingSize.setText(temp[3]);

            textLayout.addView(textViewFoodItem);
            textLayout.addView(textViewServingSize);

            rowLayout.addView(textLayout);

            LinearLayout.LayoutParams btnParam = new LinearLayout.LayoutParams(170, LinearLayout.LayoutParams.WRAP_CONTENT);
            ElegantNumberButton eleNumberBtn = new ElegantNumberButton(this);
            eleNumberBtn.setRange(1,20);
            eleNumberBtn.setNumber("1");
            eleNumberBtn.setLayoutParams(btnParam);

            rowLayout.addView(eleNumberBtn);
            linearLayout.addView(rowLayout);

            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setBackgroundColor(getResources().getColor(R.color.colorGrayIcon));
            LinearLayout.LayoutParams lineParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2,1.0f);
            line.setLayoutParams(lineParam);

            linearLayout.addView(line);

            foodIds.add(temp[0]);
            foodItems.add(textViewFoodItem);
            elegantBtns.add(eleNumberBtn);
        }
    }
    class EditDateListner implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Calendar myCalendar = Calendar.getInstance();
            int currentYear = myCalendar.get(Calendar.YEAR);
            int currentMonth = myCalendar.get(Calendar.MONTH);
            int currentDay = myCalendar.get(Calendar.DAY_OF_MONTH);
            SetDateListner setDateListner = new SetDateListner();
            DatePickerDialog dateDialog = new DatePickerDialog(view.getContext(), setDateListner,currentYear,currentMonth,currentDay);
            dateDialog.show();
        }
    }
    class SetDateListner implements DatePickerDialog.OnDateSetListener{
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year,month,day);
            editTextDate.setText(dataToString(calendar.getTime()));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_submit,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_submit:
                saveFoodRecord();
                Toast.makeText(this,"Data Saved",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this,MainActivity.class);
                intent.putExtra(Configs.USERID_PARAM_NAME,userId);
                startActivity(intent);
                break;
            case R.id.menu_cancel:
                Intent intent1 = new Intent(this,MainActivity.class);
                intent1.putExtra(Configs.USERID_PARAM_NAME,userId);
                startActivity(intent1);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    public void saveFoodRecord(){
        try{
            URL url = new URL(Configs.dailymealUrl);
            String report="";
            for(int i = 0; i< foodItems.size(); i++){
                String foodId=foodIds.get(i);
                TextView textView =foodItems.get(i);
                String foodItem = textView.getText().toString();
                ElegantNumberButton eleBtn = elegantBtns.get(i);
                String servingSize=eleBtn.getNumber();
                String date = editTextDate.getText().toString();

                report=report+foodId+","+foodItem+","+servingSize+"\n";
                String data = "id="+userId+"&foodid="+foodId+"&fooditem="+foodItem+"&servingsize="+servingSize+"&date="+date;
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                OutputStream os = urlConnection.getOutputStream();
                os.write(data.getBytes());
                os.flush();
                os.close();

                InputStream is = urlConnection.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);

                String line=br.readLine();
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private String dataToString(Date date){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String dateStr = sdf.format(date);
        return dateStr;
    }
}
