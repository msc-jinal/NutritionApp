package com.nutrition.dto;

/**
 * Created by admin on 25-02-2018.
 */

public class Profile {
    public String id;
    public String name;
    public String phone;
    public String email;
    public String age;
    public String gender;
    public String weight;
    public String height;

    public Profile(String id,String name){
        this.id=id;
        this.name=name;
    }
}