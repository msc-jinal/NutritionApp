package com.nutrition.dto;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.nutrition.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by admin on 28-02-2018.
 */

public class ExpandableListViewAdapterOld extends BaseExpandableListAdapter {

    String[] groupNames = {"Vegetables","Fruits","Cereals","Dryfruits"};
    String[][] childNames = {{"Potato","Tomato","Carrot"},{"Mango","Apple","Banana"},{"Oats","Chana"},{"Almonds","Cashewnut"}};
    Context context;
    HashMap<String,ArrayList> data;
    Set<String> myList = new HashSet<>();

    public ExpandableListViewAdapterOld(Context context, HashMap<String,ArrayList> data){
        this.context = context;
        this.data = data;
    }

    @Override
    public int getGroupCount() {
        return groupNames.length;
    }

    @Override
    public int getChildrenCount(int i) {
        return childNames[i].length;
    }

    @Override
    public Object getGroup(int i) {
        return groupNames[i];
    }

    @Override
    public Object getChild(int i, int i1) {
        return childNames[i][i1];
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupIndex, boolean b, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View groupView = layoutInflater.inflate(R.layout.group_item_row, viewGroup, false);

        TextView textView = groupView.findViewById(R.id.textview_group);
        String groupName = groupNames[groupIndex];
        textView.setText(groupName);
        return groupView;

    }

    @Override
    public View getChildView(int groupIndex, int itemIndex, boolean b, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View childView = layoutInflater.inflate(R.layout.child_item_row, viewGroup, false);

        TextView textView = childView.findViewById(R.id.textview_child);
        String itemName = childNames[groupIndex][itemIndex];
        textView.setText(itemName);

        CheckBox checkbox = childView.findViewById(R.id.chk_select);
        ChkListener chkListener = new ChkListener(myList,itemName);
        checkbox.setOnClickListener(chkListener);
        return childView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return false;
    }

}

class ChkListener implements View.OnClickListener{

    Set<String> myList;
    String itemName;
    public ChkListener(Set<String> myList,String itemName){
        this.myList = myList;
        this.itemName = itemName;
    }

    @Override
    public void onClick(View view) {
        CheckBox checkBox = (CheckBox)view;
        if(checkBox.isChecked()) {
            myList.add(itemName);
        }else{
            myList.remove(itemName);
        }
    }
}
