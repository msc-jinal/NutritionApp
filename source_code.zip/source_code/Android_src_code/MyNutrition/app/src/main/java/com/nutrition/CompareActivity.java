package com.nutrition;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CompareActivity extends AppCompatActivity {
    Button btnCompare;
    EditText editTextDate;
    String userId;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare);
        setTitle("Comparison");

        Intent intent = getIntent();
        userId=intent.getStringExtra(Configs.USERID_PARAM_NAME);
        btnCompare = (Button)findViewById(R.id.btn_compare);
        btnCompare.setOnClickListener(new CompareButtonListener());

        //inputDate
        editTextDate = (EditText) findViewById(R.id.textView_date);

        Date today = new Date();
        editTextDate.setText(dataToString(today));
        editTextDate.setOnClickListener(new EditDateListner());

        linearLayout = (LinearLayout)findViewById(R.id.compare_table);

    }


    class EditDateListner implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Calendar myCalendar = Calendar.getInstance();
            int currentYear = myCalendar.get(Calendar.YEAR);
            int currentMonth = myCalendar.get(Calendar.MONTH);
            int currentDay = myCalendar.get(Calendar.DAY_OF_MONTH);
            SetDateListner setDateListner = new SetDateListner();
            DatePickerDialog dateDialog = new DatePickerDialog(view.getContext(), setDateListner,currentYear,currentMonth,currentDay);
            dateDialog.show();
        }
    }

    class SetDateListner implements DatePickerDialog.OnDateSetListener{
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year,month,day);
            editTextDate.setText(dataToString(calendar.getTime()));
        }
    }

    class CompareButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            String date = editTextDate.getText().toString();
            String mealNutritionData= mealNutritionData(date,userId);
            String requiredNutritionData = nutritionPlanData(userId);
            String[] mealData = mealNutritionData.split(",");
            String[] requiredData = requiredNutritionData.split(",");

            //Clearing Table layout
            linearLayout.removeAllViewsInLayout();

            //Adding row into Table layout
            for(int i=0;i<mealData.length;i++){
                try {
                    String name = mealData[i].split("=")[0];
                    String mValue = mealData[i].split("=")[1];
                    String rValue = requiredData[i].split("=")[1];

                    mValue = String.valueOf(Math.round(Float.parseFloat(mValue)));
                    rValue = String.valueOf(Math.round(Float.parseFloat(rValue)));

                    LinearLayout l1 = new LinearLayout(view.getContext());
                    l1.setOrientation(LinearLayout.HORIZONTAL);
                    l1.setPadding(0, 20, 0, 5);
                    LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                    TextView textView1 = new TextView(view.getContext());
                    textView1.setText(name);
                    textView1.setLayoutParams(param);
                    int width = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,80,getResources().getDisplayMetrics());
                    TextView textView2 = new TextView(view.getContext());
                    textView2.setText(mValue);
                    textView2.setWidth(width);
                    TextView textView3 = new TextView(view.getContext());
                    textView3.setText(rValue);
                    textView3.setWidth(width);

                    l1.addView(textView1);
                    l1.addView(textView2);
                    l1.addView(textView3);

                    //Add row layout in main layout
                    linearLayout.addView(l1);

                    LinearLayout line = new LinearLayout(view.getContext());
                    line.setOrientation(LinearLayout.HORIZONTAL);
                    if (difference(mValue, rValue) > 20) {
                        line.setBackgroundColor(getResources().getColor(R.color.colorAlert));
                    } else {
                        line.setBackgroundColor(getResources().getColor(R.color.colorGrayIcon));
                    }
                    LinearLayout.LayoutParams lineParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2, 1.0f);
                    line.setLayoutParams(lineParam);

                    //Add line after each row in main layout
                    linearLayout.addView(line);
                }catch (Exception ex){
                    Log.e("NutritionCompare",ex.getMessage());
                }

            }
        }
    }
    public String mealNutritionData(String date,String userId){
        String mealNutritionRecord="";

        try{
            URL url = new URL(Configs.calculateNutritionValueUrl);
            String data = "id="+userId+"&date="+date;

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            mealNutritionRecord=br.readLine();

        }catch (Exception e){
            e.printStackTrace();
        }
        return mealNutritionRecord;

    }
    public String nutritionPlanData(String userId){
        String nutritionPlanRecord="";

        try{
            URL url = new URL(Configs.getNnutritionPlanUrl);
            String data = "id="+userId;

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            nutritionPlanRecord=br.readLine();

        }catch (Exception e){
            e.printStackTrace();
        }
        return nutritionPlanRecord;

    }
    private String dataToString(Date date){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String dateStr = sdf.format(date);
        return dateStr;
    }

    private float difference(String val1, String val2){
        try {
            float v1 = Float.parseFloat(val1);
            float v2 = Float.parseFloat(val2);
            float diff = ((v1-v2)/((v1+v2)/2))*100;
            diff = Math.abs(diff);
            return diff;
        }catch (Exception ex){
            return 0;
        }
    }
}
