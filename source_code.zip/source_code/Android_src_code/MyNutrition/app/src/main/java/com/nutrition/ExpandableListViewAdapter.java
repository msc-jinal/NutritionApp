package com.nutrition;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by admin on 28-02-2018.
 */

public class ExpandableListViewAdapter extends BaseExpandableListAdapter {

    Context context;
    HashMap<String,ArrayList> data;
    ArrayList<String> selectedItems = new ArrayList<>();
    ArrayList<String> headings = new ArrayList<>();

    public ExpandableListViewAdapter(Context context, HashMap<String,ArrayList> data){
        this.context = context;
        this.data = data;

        for(String heading : data.keySet()) {
            headings.add(heading);
        }

    }

    @Override
    public int getGroupCount() {
        return headings.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return ((data.get(headings.get(i))).size());
    }

    @Override
    public Object getGroup(int i) {
        return headings.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
       ArrayList l =  (data.get(headings.get(i)));
       return l.get(i1);
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupIndex, boolean b, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View groupView = layoutInflater.inflate(R.layout.group_item_row, viewGroup, false);

        TextView textView = groupView.findViewById(R.id.textview_group);
        String groupName = headings.get(groupIndex);
        textView.setText(groupName);
        return groupView;

    }
    @Override
    public View getChildView(int groupIndex, int itemIndex, boolean b, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View childView = layoutInflater.inflate(R.layout.child_item_row, viewGroup, false);

        TextView textViewName = childView.findViewById(R.id.textview_child);
        TextView textViewSize = childView.findViewById(R.id.textview_servingSize);
        ArrayList<String> tempList = data.get(headings.get(groupIndex));
        String str = tempList.get(itemIndex);
        String[] tempStr = str.split("#");
        String itemName = tempStr[1];
        String servingSize = tempStr[3];

        textViewName.setText(itemName);
        textViewSize.setText(servingSize);

        CheckBox checkbox = childView.findViewById(R.id.chk_select);
        ChkListener chkListener = new ChkListener(selectedItems,str);
        if(selectedItems.contains(str)){
            checkbox.setChecked(true);
        }
        checkbox.setOnClickListener(chkListener);
        return childView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return false;
    }

}

class ChkListener implements View.OnClickListener{

    ArrayList<String> selectedItems;
    String itemName;
    public ChkListener(ArrayList<String> selectedItems,String itemName){
        this.selectedItems = selectedItems;
        this.itemName = itemName;
    }

    @Override
    public void onClick(View view) {
        CheckBox checkBox = (CheckBox)view;
        if(checkBox.isChecked()) {
            selectedItems.add(itemName);
        }else{
            selectedItems.remove(itemName);
        }
    }
}
