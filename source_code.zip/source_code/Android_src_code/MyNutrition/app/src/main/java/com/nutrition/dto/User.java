package com.nutrition.dto;


/**
 * Created by admin on 25-02-2018.
 */

public class User{
    public Profile profile;
    public MedicalHistory medicalHistory;

}