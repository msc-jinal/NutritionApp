package com.nutrition;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MedicalProfileStep1Activity extends AppCompatActivity {
    EditText editTextAge,editTextWeight,editTextHeight;
    RadioGroup radioGroupGender,radioGroupLifeStyle;
    RadioButton rBtnMale,rBtnFemale,rBtnLfSedentary,rBtnLfActive,rBtnLfHard;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_personal_profile);
        setTitle("Medical Profile");

        Intent intent = getIntent();
        userId=intent.getStringExtra(Configs.USERID_PARAM_NAME);

        editTextAge = (EditText)findViewById(R.id.editText_age);
        editTextWeight = (EditText)findViewById(R.id.editText_weight);
        editTextHeight = (EditText) findViewById(R.id.editText_height);
        radioGroupGender = (RadioGroup)findViewById(R.id.radioGroup_gender);
        rBtnMale = (RadioButton)findViewById(R.id.radioBtn_male);
        rBtnFemale = (RadioButton)findViewById(R.id.radioBtn_female);
        radioGroupLifeStyle = (RadioGroup)findViewById(R.id.radioGroup_lifestye);
        rBtnLfSedentary = (RadioButton) findViewById(R.id.radioBtn_sedentary);
        rBtnLfActive = (RadioButton) findViewById(R.id.radioBtn_active);
        rBtnLfHard = (RadioButton) findViewById(R.id.radioBtn_hardworking);

        loadUserProfile();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_next,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_next:
                if(validate()){
                    moveNext();
                }
                break;
            case R.id.menu_cancel:
                Intent intent = new Intent(this,MainActivity.class);
                intent.putExtra(Configs.USERID_PARAM_NAME,userId);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void moveNext(){
        try {
            int chckedId = radioGroupGender.getCheckedRadioButtonId();
            RadioButton rBtnGender = (RadioButton) this.findViewById(chckedId);

            chckedId = radioGroupLifeStyle.getCheckedRadioButtonId();
            RadioButton rBtnLifeStyle = (RadioButton) this.findViewById(chckedId);

            Intent intent = new Intent(this,MedicalProfileStep2Activity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME,userId);
            intent.putExtra("age",editTextAge.getText().toString());
            intent.putExtra("gender",rBtnGender.getText().toString());
            intent.putExtra("weight",editTextWeight.getText().toString());
            intent.putExtra("height",editTextHeight.getText().toString());
            intent.putExtra("lifestyle",rBtnLifeStyle.getText().toString());
            startActivity(intent);
        }catch (Exception ex){
            Log.e("PROFILE","Error to save Personal Profile");
        }
    }

    private boolean validate(){
        boolean isValidate=true;
        if(editTextAge.getText().toString()==null || editTextAge.getText().toString().isEmpty()){
            editTextAge.setError("Required!");
            isValidate=false;
        }
        if(editTextWeight.getText().toString()==null || editTextWeight.getText().toString().isEmpty()){
            editTextWeight.setError("Required!");
            isValidate=false;
        }
        if(editTextHeight.getText().toString()==null || editTextHeight.getText().toString().isEmpty()){
            editTextHeight.setError("Required!");
            isValidate=false;
        }
        if(radioGroupGender.getCheckedRadioButtonId() <0){
            Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
            isValidate=false;
        }
        if(radioGroupLifeStyle.getCheckedRadioButtonId() <0){
            Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
            isValidate=false;
        }

        return isValidate;
    }

    public void loadUserProfile(){
        try{
            URL url = new URL(Configs.medicalProfileUrl);
            String data = "id="+userId;

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            String line=br.readLine();
            String[] record = line.split(",");
            editTextAge.setText(record[0].split("=")[1]);
            editTextWeight.setText(record[2].split("=")[1]);
            editTextHeight.setText(record[3].split("=")[1]);
            if(record[1].split("=")[1].equalsIgnoreCase("Male")){
                rBtnMale.setChecked(true);
            }
            else{
                rBtnFemale.setChecked(true);
            }
            if(record[4].split("=")[1].equalsIgnoreCase("Sedentary")){
                rBtnLfSedentary.setChecked(true);

            }else if(record[4].split("=")[1].equalsIgnoreCase("Active")){
                rBtnLfActive.setChecked(true);

            }else{
                rBtnLfHard.setChecked(true);

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
