package com.nutrition;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnAddProfile,btnAddMeal,btnNutritionPlan,btnCompare,btnfoodHistory;
    String userId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Nutrition");

        btnAddProfile = (Button) findViewById(R.id.btn_addProfile);
        btnAddMeal = (Button) findViewById(R.id.btn_addMeal);
        btnNutritionPlan = (Button) findViewById(R.id.btn_nutritionPlan);
        btnCompare = (Button) findViewById(R.id.btn_compare);
        btnfoodHistory = (Button) findViewById(R.id.btn_foodHistory);

        AddProfileButtonListener addProfileButtonListener = new AddProfileButtonListener();
        btnAddProfile.setOnClickListener(addProfileButtonListener);

        AddMealButtonListener addMealButtonListener = new AddMealButtonListener();
        btnAddMeal.setOnClickListener(addMealButtonListener);

        NutritionPlanButtonListener nutritionPlanButtonListener = new NutritionPlanButtonListener();
        btnNutritionPlan.setOnClickListener(nutritionPlanButtonListener);

        CompareButtonListener compareButtonListener = new CompareButtonListener();
        btnCompare.setOnClickListener(compareButtonListener);

        FoodHistoryButtonListener foodHistoryButtonListener = new FoodHistoryButtonListener();
        btnfoodHistory.setOnClickListener(foodHistoryButtonListener);

        Intent intent = getIntent();
        userId=intent.getStringExtra(Configs.USERID_PARAM_NAME);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_logout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.menu_logout){
            this.finish();
            System.exit(0);
        }
        return super.onOptionsItemSelected(item);
    }

    class AddProfileButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(view.getContext(),MedicalProfileStep1Activity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME,userId);
            startActivity(intent);
        }
    }

    class AddMealButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(view.getContext(),AddDailyMealActivity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME,userId);
            startActivity(intent);
        }
    }

    class NutritionPlanButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {

            Intent intent = new Intent(view.getContext(),NutritionReportActivity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME,userId);
            startActivity(intent);

        }
    }

    class CompareButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {

            Intent intent = new Intent(view.getContext(),CompareActivity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME,userId);
            startActivity(intent);

        }
    }

    class FoodHistoryButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {

            Intent intent = new Intent(view.getContext(),FoodHistoryActivity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME,userId);
            startActivity(intent);

        }
    }


}
