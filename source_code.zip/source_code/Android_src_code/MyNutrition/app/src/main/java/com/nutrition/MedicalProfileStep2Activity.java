package com.nutrition;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MedicalProfileStep2Activity extends AppCompatActivity {
    EditText editTextSugar,editTextBP,editTextHb,editTextK,editTextNa,editTextCa;
    EditText editTextChol,editTextTri,editTextHDL,editTextLDL,editTextVLDL;
    String age,gender,weight,height,lifestyle;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medical_history);
        setTitle("Medical Profile (Cont.)");

        Intent intent = getIntent();
        userId = intent.getStringExtra(Configs.USERID_PARAM_NAME);
        age=intent.getStringExtra("age");
        gender=intent.getStringExtra("gender");
        weight=intent.getStringExtra("weight");
        height=intent.getStringExtra("height");
        lifestyle=intent.getStringExtra("lifestyle");

        editTextSugar = (EditText) findViewById(R.id.editText_sugar);
        editTextBP = (EditText) findViewById(R.id.editText_bp);
        editTextHb = (EditText) findViewById(R.id.editText_hb);
        editTextK = (EditText) findViewById(R.id.editText_K);
        editTextNa = (EditText) findViewById(R.id.editText_Na);
        editTextCa = (EditText) findViewById(R.id.editText_Ca);
        editTextChol = (EditText)findViewById(R.id.editText_Cholesterol);
        editTextTri = (EditText) findViewById(R.id.editText_Triglyceride);
        editTextHDL = (EditText) findViewById(R.id.editText_Hdl);
        editTextLDL = (EditText) findViewById(R.id.editText_Ldl);
        editTextVLDL = (EditText) findViewById(R.id.editText_Vldl);

        loadUserProfile();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_submit,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_submit:
                submit();
                break;
            case R.id.menu_cancel:
                Intent intent = new Intent(this,MainActivity.class);
                intent.putExtra(Configs.USERID_PARAM_NAME,userId);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void submit(){
        try{
            boolean result1 = saveRecord();
            boolean result2 = generateNutritionPlan();
            if(result1 == true && result2==true) {
                Toast.makeText(this, "Record Saved!!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("userid",userId);
                startActivity(intent);
            }

        }catch (Exception ex){
            Log.e("PROFILE","Error to save Medical History");
        }
    }

    public void loadUserProfile(){
        try{
            URL url = new URL(Configs.medicalProfileUrl);
            String data = "id="+userId;

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            String line=br.readLine();
            String[] record = line.split(",");
            editTextSugar.setText(record[5].split("=")[1]);
            editTextBP.setText(record[6].split("=")[1]);
            editTextHb.setText(record[7].split("=")[1]);
            editTextK.setText(record[8].split("=")[1]);
            editTextNa.setText(record[9].split("=")[1]);
            editTextCa.setText(record[10].split("=")[1]);
            editTextChol.setText(record[11].split("=")[1]);
            editTextTri.setText(record[12].split("=")[1]);
            editTextHDL.setText(record[13].split("=")[1]);
            editTextLDL.setText(record[14].split("=")[1]);
            editTextVLDL.setText(record[15].split("=")[1]);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public boolean saveRecord(){
        try{
            String sugar = editTextSugar.getText().toString();
            String bp = editTextBP.getText().toString();
            String haemoglobin = editTextHb.getText().toString();
            String potassium = editTextK.getText().toString();
            String sodium = editTextNa.getText().toString();
            String calcium = editTextCa.getText().toString();
            String cholesterol = editTextChol.getText().toString();
            String triglyceride = editTextTri.getText().toString();
            String hdl = editTextHDL.getText().toString();
            String ldl = editTextLDL.getText().toString();
            String vldl =editTextVLDL.getText().toString();

            String data = "id="+userId+"&age="+age+"&gender="+gender+"&weight="+weight+"&height="+height+"&lifestyle="+lifestyle
                    +"&sugar="+sugar+"&bp="+bp+"&haemoglobin="+haemoglobin+"&potassium="+potassium+"&sodium="+sodium+"&calcium="+calcium
                    +"&cholesterol="+cholesterol+"&triglyceride="+triglyceride+"&hdl="+hdl+"&ldl="+ldl+"&vldl="+vldl;

            URL url = new URL(Configs.CreateMedicalProfileUrl);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setRequestMethod("POST");

            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line=br.readLine();
            if(line.contains("Failed")){
                return false;
            }else{
                return true;
            }
        }catch(Exception e){
            return false;
        }
    }

    public boolean generateNutritionPlan(){

        try{
            String data = "id="+userId+"&age="+age+"&gender="+gender+"&weight="+weight+"&height="+height+"&lifestyle="+lifestyle;
            URL url = new URL(Configs.generateNutritionPlanUrl);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setRequestMethod("POST");

            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line=br.readLine();
            if(line.contains("Failed")){
                return false;
            }else{
                return true;
            }
        }catch(Exception e){
            return false;
        }
    }
}
