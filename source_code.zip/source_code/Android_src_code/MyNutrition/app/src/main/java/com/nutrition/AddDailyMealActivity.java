package com.nutrition;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

public class AddDailyMealActivity extends AppCompatActivity {
    ExpandableListView expandableListView;
    String userId;
    ExpandableListViewAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_daily_meal);
        setTitle("My Meal");

        Intent intent = getIntent();
        userId=intent.getStringExtra(Configs.USERID_PARAM_NAME);

        expandableListView = (ExpandableListView) findViewById(R.id.expand_listview);
        //Read data from DB, using HTTP Request
        ArrayList<String> myList = readData();
        //Created ArrayList or Map
        HashMap<String,ArrayList> data= extractData(myList);
        //Pass Data to Adapter, while create adapter object

        adapter = new ExpandableListViewAdapter(this,data);
        expandableListView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_next,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_next:
                saveRecord();
                break;
            case R.id.menu_cancel:
                Intent intent = new Intent(this,MainActivity.class);
                intent.putExtra(Configs.USERID_PARAM_NAME,userId);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public ArrayList<String> readData(){
        String urlLink = Configs.foodItemsUrl;
        ArrayList<String> list = new ArrayList<>();
        try{
            URL url = new URL(urlLink);
            URLConnection urlConnection = url.openConnection();
            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            String line;
            while((line=br.readLine()) !=null){
                list.add(line);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public HashMap<String,ArrayList> extractData(ArrayList<String> myList){
        HashMap<String,ArrayList> data = new HashMap<>();

        for(int i=0;i<myList.size();i++){
            String str=myList.get(i);
            String[] temp = str.split("#");

            String k = temp[2];
            String v = str;
            ArrayList list;
            if(data.containsKey(k)){
                list = data.get(k);
                list.add(v);
            }
            else{
                list = new ArrayList();
                list.add(v);
                data.put(k,list);
            }
        }
        return data;
    }
    public void saveRecord(){
        ArrayList mySelectedList = adapter.selectedItems;
        if(mySelectedList.size()>0) {
            Intent intent = new Intent(this, PrepareMealRecordActivity.class);
            intent.putExtra(Configs.USERID_PARAM_NAME, userId);
            intent.putExtra("mySelectedList", mySelectedList);
            startActivity(intent);
        }else{
            Toast.makeText(this,"Please choose, your food!!",Toast.LENGTH_SHORT).show();
        }
    }

}
