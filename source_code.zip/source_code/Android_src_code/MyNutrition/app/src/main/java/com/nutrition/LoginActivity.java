package com.nutrition;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;

public class LoginActivity extends AppCompatActivity {

    EditText editTextEmail,editTextPassword;
    Button btnLogin,btnRegistration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setTitle("Login");

        editTextEmail = (EditText)findViewById(R.id.editText_email);
        editTextPassword = (EditText)findViewById(R.id.editText_password);

        btnLogin = (Button) findViewById(R.id.btn_login);
        btnRegistration = (Button) findViewById(R.id.btn_registration);

        btnLogin.setOnClickListener(new LoginButtonListener());
        btnRegistration.setOnClickListener(new RegistrationButtonListener());

        grantPermission();
    }
    private void grantPermission(){
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    class LoginButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            try{
                if(validate()) {
                    String userId = loginValidation();
                    if (userId != null) {
                        Toast.makeText(view.getContext(), "Login success!!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(view.getContext(), MainActivity.class);
                        intent.putExtra(Configs.USERID_PARAM_NAME, userId);
                        startActivity(intent);
                    } else {
                        Toast.makeText(view.getContext(), "Invalid Email or Password...", Toast.LENGTH_LONG).show();
                    }
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    class RegistrationButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(view.getContext(),RegistrationActivity.class);
            startActivity(intent);
        }
    }
    private String loginValidation(){
        String userId=null;
        try{

            String email = editTextEmail.getText().toString();
            String password = editTextPassword.getText().toString();
            String data = "email="+email+"&password="+password;

            URL url = new URL(Configs.loginUrl);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);

            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            String response = br.readLine();
            if(response.contains("Failed")){
                return null;
            }else{
                userId=response;
            }
        }catch (Exception e){
            Log.e("WEBCALL","Login Failed");
        }
        return userId;
    }

    private boolean validate(){
        boolean isValidate=true;
        if(editTextEmail.getText().toString()==null || editTextEmail.getText().toString().isEmpty()){
            editTextEmail.setError("Required!");
            isValidate=false;
        }
        if(editTextPassword.getText().toString()==null || editTextPassword.getText().toString().isEmpty()){
            editTextPassword.setError("Required!");
            isValidate=false;
        }
        return isValidate;
    }
}
