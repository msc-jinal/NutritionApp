package com.nutrition.dto;

/**
 * Created by admin on 25-02-2018.
 */

public class MedicalHistory {

    public String id;
    public String sugar;
    public String bp;
    public String hb;
    public String pot;
    public String sod;
    public String cal;
    public String chol;
    public String tri;
    public String hdl;
    public String ldl;
    public String vldl;


    public MedicalHistory (String id){
        this.id=id;
    }
}