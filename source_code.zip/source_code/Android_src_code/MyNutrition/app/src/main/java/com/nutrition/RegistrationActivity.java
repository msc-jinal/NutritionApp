package com.nutrition;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;

public class RegistrationActivity extends AppCompatActivity {

    EditText editTextName,editTextPhone,editTextEmail,editTextPassword;
    Button btnSubmit,btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setTitle("Registration");

        editTextName = (EditText)findViewById(R.id.editText_name);
        editTextPhone = (EditText)findViewById(R.id.editText_phone);
        editTextEmail = (EditText)findViewById(R.id.editText_email);
        editTextPassword = (EditText)findViewById(R.id.editText_password);

        btnSubmit = (Button) findViewById(R.id.btn_submit);
        btnCancel = (Button) findViewById(R.id.btn_cancel);

        btnSubmit.setOnClickListener(new SubmitButtonListener());
        btnCancel.setOnClickListener(new CancelButtonListener());

        grantPermission();
    }


    private void grantPermission(){
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    class SubmitButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            try {
                if(validate()) {
                    String userId = registration();
                    if (userId != null) {
                        Toast.makeText(view.getContext(), "Registration success!!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(view.getContext(), MainActivity.class);
                        intent.putExtra("userid", userId);
                        startActivity(intent);
                    }
                }
            }catch (Exception ex){
                Log.e("PROFILE","Error to save Personal Profile");
            }
        }
    }
    class CancelButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(view.getContext(), LoginActivity.class);
            startActivity(intent);
        }
    }

    private boolean validate(){
        boolean isValidate=true;
        if(editTextName.getText().toString()==null || editTextName.getText().toString().isEmpty()){
            editTextName.setError("Required!");
            isValidate=false;
        }
        if(editTextPhone.getText().toString()==null || editTextPhone.getText().toString().isEmpty()){
            editTextPhone.setError("Required!");
            isValidate=false;
        }
        if(editTextEmail.getText().toString()==null || editTextEmail.getText().toString().isEmpty()){
            editTextEmail.setError("Required!");
            isValidate=false;
        }
        if(editTextPassword.getText().toString()==null || editTextPassword.getText().toString().isEmpty()){
            editTextPassword.setError("Required!");
            isValidate=false;
        }
        return isValidate;
    }

    private String registration(){
        String userId=null;
        try{
            String name = editTextName.getText().toString();
            String phone = editTextPhone.getText().toString();
            String email = editTextEmail.getText().toString();
            String password = editTextPassword.getText().toString();

            String postData = "name="+name+"&phone="+phone+"&email="+email+"&password="+password;

            URL url = new URL(Configs.registrationUrl);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setRequestMethod("POST");

            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(postData.getBytes());
            os.flush();
            os.close();


            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            String line=br.readLine();
            if(line.contains("Failed")){
                return null;
            }else{
                userId=line;
            }

        }catch(Exception e){
            Log.e("WEBCALL","Registration Failed");
        }
        return userId;
    }
}
