package com.nutrition;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class FoodHistoryActivity extends AppCompatActivity {
    EditText editTextDate;
    Button btnShow;
    LinearLayout layout;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_history);
        setTitle("Food History");

        Intent intent = getIntent();
        userId = intent.getStringExtra(Configs.USERID_PARAM_NAME);

        editTextDate = (EditText) findViewById(R.id.textView_date);
        btnShow = (Button) findViewById(R.id.btn_show);
        Date today = new Date();
        editTextDate.setText(dataToString(today));
        editTextDate.setOnClickListener(new EditDateListner());
        ShowButtonListener showButtonListener = new ShowButtonListener();
        btnShow.setOnClickListener(showButtonListener);

        layout = (LinearLayout) findViewById(R.id.compare_table);

    }

    // set date picker dialog in EditDateListener
    class EditDateListner implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Calendar myCalendar = Calendar.getInstance();
            int currentYear = myCalendar.get(Calendar.YEAR);
            int currentMonth = myCalendar.get(Calendar.MONTH);
            int currentDay = myCalendar.get(Calendar.DAY_OF_MONTH);
            SetDateListner setDateListner = new SetDateListner();
            DatePickerDialog dateDialog = new DatePickerDialog(view.getContext(), setDateListner, currentYear, currentMonth, currentDay);
            dateDialog.show();
        }
    }

    class SetDateListner implements DatePickerDialog.OnDateSetListener {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, day);
            editTextDate.setText(dataToString(calendar.getTime()));
        }
    }

    //convert date into simple date format
    private String dataToString(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String dateStr = sdf.format(date);
        return dateStr;
    }

    class ShowButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            displayRecord();
        }
    }
    //display records
    public void displayRecord(){
        String selectedDate = editTextDate.getText().toString();
        String data=getFoodRecord(selectedDate,userId);

        //Clearing Table layout
        layout.removeAllViewsInLayout();

        if(data == null){
            Toast.makeText(this,"No Data Found!",Toast.LENGTH_SHORT).show();
        }
        else{
            String[] str1 = data.split("@");

            for(int i=0;i<str1.length;i++){
                String temp = str1[i];
                String[] str2 = temp.split("#");
                String food = str2[0].split("=")[1];
                String size = str2[1].split("=")[1];
                String quantity = str2[2].split("=")[1];

                LinearLayout rowLayout = new LinearLayout(this);
                rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                rowLayout.setPadding(0, 20, 0, 5);

                LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);

                LinearLayout leftLayout = new LinearLayout(this);
                leftLayout.setOrientation(LinearLayout.VERTICAL);
                leftLayout.setLayoutParams(param);

                TextView textViewName = new TextView(this);
                textViewName.setText(food);
                TextView textViewSize = new TextView(this);
                textViewSize.setText(size);

                leftLayout.addView(textViewName);
                leftLayout.addView(textViewSize);

                LinearLayout rightLayout = new LinearLayout(this);
                rightLayout.setOrientation(LinearLayout.VERTICAL);
                TextView textViewQnt = new TextView(this);
                textViewQnt.setText(quantity);
                int width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,80,getResources().getDisplayMetrics());
                textViewQnt.setWidth(width);
                rightLayout.addView(textViewQnt);

                rowLayout.addView(leftLayout);
                rowLayout.addView(rightLayout);

                layout.addView(rowLayout);
            }
        }
    }
    // Read Food History
    public String getFoodRecord(String date,String userId){
        String foodRecord="";

        try{
            URL url = new URL(Configs.foodHistoryUrl);

            String data = "id="+userId+"&date="+date;

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            foodRecord=br.readLine();

        }catch(Exception e){
            e.printStackTrace();
        }
        return foodRecord;
    }
}
