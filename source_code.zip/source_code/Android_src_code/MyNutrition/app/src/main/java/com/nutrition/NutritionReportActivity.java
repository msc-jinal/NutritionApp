package com.nutrition;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class NutritionReportActivity extends AppCompatActivity {
    String userId;
    LinearLayout l1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition_report);
        setTitle("Nutrition Plan");

        l1 = findViewById(R.id.linearLayout);
        Intent intent = getIntent();
        userId = intent.getStringExtra(Configs.USERID_PARAM_NAME);
        displayResult(userId);
    }

    public void displayResult(String userId){
        try {
            String requiredNutritionData = nutritionPlanData(userId);
            String[] requiredData = requiredNutritionData.split(",");
            for (int i = 0; i < requiredData.length; i++) {
                try {
                    String name = requiredData[i].split("=")[0];
                    String rValue = requiredData[i].split("=")[1];

                    rValue = String.valueOf(Math.round(Float.parseFloat(rValue)));
                    LinearLayout l2 = new LinearLayout(this);
                    l2.setOrientation(LinearLayout.HORIZONTAL);
                    l2.setPadding(0, 20, 0, 5);

                    LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                    TextView textView1 = new TextView(this);
                    textView1.setText(name);
                    textView1.setLayoutParams(param);
                    textView1.setTextSize(15);

                    TextView textView2 = new TextView(this);
                    textView2.setText(rValue);
                    textView2.setTextSize(15);
                    int width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,80,getResources().getDisplayMetrics());
                    textView2.setWidth(width);
                    l2.addView(textView1);
                    l2.addView(textView2);
                    //Add row layout in main layout
                    l1.addView(l2);

                    LinearLayout line = new LinearLayout(this);
                    line.setOrientation(LinearLayout.HORIZONTAL);
                    line.setBackgroundColor(getResources().getColor(R.color.colorGrayIcon));
                    LinearLayout.LayoutParams lineParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2, 1.0f);
                    line.setLayoutParams(lineParam);

                    //Add line after each row in main layout
                    l1.addView(line);

                } catch (Exception ex) {
                    Log.e("NutritionReport", ex.getMessage());
                }
            }
        }catch(Exception e){
            Log.e("NutritionReport",e.getMessage());
        }

    }

    public String nutritionPlanData(String userId){
        String nutritionPlanRecord="";

        try{
            URL url = new URL(Configs.getNnutritionPlanUrl);
            String data = "id="+userId;

            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            OutputStream os = urlConnection.getOutputStream();
            os.write(data.getBytes());
            os.flush();
            os.close();

            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            nutritionPlanRecord=br.readLine();

        }catch (Exception e){
            e.printStackTrace();
        }
        return nutritionPlanRecord;
    }
}
