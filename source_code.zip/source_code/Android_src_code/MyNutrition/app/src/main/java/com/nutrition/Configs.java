package com.nutrition;

/**
 * Created by admin on 03-03-2018.
 */

public class Configs {
    private static String appUrl = "http://13.126.184.17:8080/nutrition";
    public static String foodItemsUrl = appUrl+"/fooditems";
    public static String registrationUrl = appUrl+"/registration";
    public static String loginUrl = appUrl+"/login";
    public static String CreateMedicalProfileUrl = appUrl+"/createmedicalprofile";
    public static String medicalProfileUrl = appUrl+"/medicalprofile";
    public static String dailymealUrl = appUrl+"/dailymeal";
    public static String calculateNutritionValueUrl = appUrl+"/calculatenutritionvalue";
    public static String getNnutritionPlanUrl = appUrl+"/getnutritionplan";
    public static String generateNutritionPlanUrl = appUrl+"/generatenutritionplan";
    public static String foodHistoryUrl = appUrl+"/foodhistory";


    public static String USERID_PARAM_NAME = "userid";
}
